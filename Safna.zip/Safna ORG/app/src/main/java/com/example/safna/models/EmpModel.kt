package com.example.safna.models

data class EmpModel (
    var Username: String? = null,
    var Email: String? = null,
    var Linkedin: String? = null,
    var Job: String? = null,
    var Telno: String? = null,

    )