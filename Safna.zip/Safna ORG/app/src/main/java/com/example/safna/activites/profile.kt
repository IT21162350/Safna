package com.example.safna.activites

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.safna.R


class profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)


    }
}